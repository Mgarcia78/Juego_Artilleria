﻿using UnityEngine;
using System.Collections;

public class Gun : MonoBehaviour
{
    public Rigidbody2D rocket;              // Prefab of the rocket.
    public Sprite attackBarSprite;
    public delegate void GunFired();
    public event GunFired gunFired;
    private Animator anim;					// Reference to the Animator component.
    private enum States
    {
        Down, Fire, Up, FireBomb
    }
    private States state = States.Up;
    private float speed = 0f;               // The speed the rocket will fire at.
    private float targetSpeed = 0f;
    private Transform attackBar;
    
    private PlayerControl playerCtrl;		// Reference to the PlayerControl script.  
    public Rigidbody2D bomb;              // Prefab of the rocket.

    public bool activaBomba = false; //Controla si los controles para disparar la bomba estan activos (se llama desde "HaveBombs")

    void Awake()
	{
		// Setting up the references.
		anim = transform.root.gameObject.GetComponent<Animator>();
        playerCtrl = transform.root.GetComponent<PlayerControl>();
        
        GameObject attackBarObject = new GameObject("Power");
        attackBar = attackBarObject.transform;
        attackBar.SetParent(transform);
        attackBar.localPosition = Vector3.zero;
        attackBar.localRotation = Quaternion.identity;
        attackBar.localScale = Vector3.up * 2 + Vector3.forward;

        SpriteRenderer rend = attackBarObject.AddComponent<SpriteRenderer>();
        rend.sprite = attackBarSprite;
        rend.sortingLayerID = transform.root.GetComponentInChildren<SpriteRenderer>().sortingLayerID;
    }

    void Update()
    {
        if (targetSpeed > 0)
        {
            state = States.Down;
            if (speed >= targetSpeed) state = States.Fire;
        }
        switch (state)
        {
            case States.Down:
                speed += Time.deltaTime * 30;
                attackBar.localScale += Vector3.right * 0.01f;
                attackBar.GetComponent<SpriteRenderer>().color = Color.Lerp(Color.green, Color.red, attackBar.localScale.x);
                break;
            case States.Fire:
                Fire();
                state = States.Up;
                break;
            case States.FireBomb:
                FireBomb();
                state = States.Up;
                break;
        }

        // Comprueba si es el turno del jugador para activar los controles por teclado
        if (playerCtrl.hasTurn == true)
        {
            //Al pulsar la tecla (Ctrl derecho) activa la barra de disparo del misil
            if (Input.GetKeyDown(KeyCode.LeftControl))
            {
                FireDown();
            }
            // Al soltar la tecla (Ctrl derecho) dispara el proyectil
            else if (Input.GetKeyUp(KeyCode.LeftControl))
            {
                FireUp();
            }

            //Controla si los controles para disparar la bomba estan activos (se llama desde "HaveBombs")
            if (activaBomba == true)
            {
                //Al pulsar la tecla (Mays derecha) activa la barra de disparo de la bomba
                if (Input.GetKeyDown(KeyCode.LeftShift))
                {
                    Bomb_FireDown();
                }
                // Al soltar la tecla (Ctrl derecho) dispara el proyectil
                else if (Input.GetKeyUp(KeyCode.LeftShift))
                {
                    Bomb_FireUp();
                }
            }  
        }
        else
        {
            //Resetea "activaBomba" para que no se pueda disparar si "bomHUD" no esta activado (esta en "HaveBombs" script)
            activaBomba = false;
        }
    }

    public void FireUp()
    {
        state = States.Fire;
    }

    public void FireDown()
    {
        state = States.Down;
    }
    
    public void Fire()
    {
        anim.SetTrigger("Shoot");
        GetComponent<AudioSource>().Play();

        //Si el jugador esta del lado derecho
        Rigidbody2D bulletInstance = Instantiate(rocket, transform.position, transform.rotation) as Rigidbody2D;

        if (transform.root.GetComponent<PlayerControl>().facingRight)
        {
            bulletInstance.velocity = transform.right.normalized * speed;
        }
        else
        {
            //Esta instruccion controla el angulo de disparo del misil
            bulletInstance.velocity = new Vector2(-transform.right.x, Mathf.Abs(transform.right.y)).normalized * speed;
        }

        bulletInstance.GetComponentInChildren<Rocket>().ignoreTag = transform.root.tag;
        targetSpeed = speed = 0;
        attackBar.localScale = Vector3.up * 2 + Vector3.forward;

        if (gunFired != null)
        {
            gunFired();
        }
    }
        
    public void Fire(float targetSpeed)
    {
        this.targetSpeed = targetSpeed;
    }


    public void Bomb_FireUp()
    {
        state = States.FireBomb;
    }

    public void Bomb_FireDown()
    {
        state = States.Down;
    }

    public void FireBomb()
    {
        anim.SetTrigger("Shoot");
        GetComponent<AudioSource>().Play();

        //Si el jugador esta del lado derecho
        Rigidbody2D bulletInstance = Instantiate(bomb, transform.position, transform.rotation) as Rigidbody2D;

        if (transform.root.GetComponent<PlayerControl>().facingRight)
        {
            bulletInstance.velocity = transform.right.normalized * speed;
        }
        else
        {
            //Esta instruccion controla el angulo de disparo del misil
            bulletInstance.velocity = new Vector2(-transform.right.x, Mathf.Abs(transform.right.y)).normalized * speed;
        }

        //bulletInstance.GetComponentInChildren<Bomb>().ignoreTag = transform.root.tag;
        targetSpeed = speed = 0;
        attackBar.localScale = Vector3.up * 2 + Vector3.forward;

        if (gunFired != null)
        {
            gunFired();
        }
    }

    public void Bomb_Fire(float targetSpeed)
    {
        this.targetSpeed = targetSpeed;
    }
}
