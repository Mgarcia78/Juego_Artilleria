﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shield : MonoBehaviour {

    void Start()
    {
        // Destroy the rocket after 1 seconds if it doesn't get destroyed before then.
        Destroy(gameObject, 1);
    }
}
